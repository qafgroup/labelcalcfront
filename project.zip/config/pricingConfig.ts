// ملف معادلات التسعير - قابل للتعديل بسهولة
// يمكنك تعديل الأسعار هنا حسب احتياجات شركتك

export const PRICING_CONFIG = {
  // سعر المتر المربع الأساسي (بالريال)
  basePricePerSqm: 50,

  // تكلفة إضافية حسب نوع الطباعة (بالريال لكل متر مربع)
  printTypes: {
    'cmyk-4': 0, // الأساسي
    'colors-5': 15,
    'colors-6': 25,
    'colors-7': 35,
  },

  // تكلفة إضافية حسب نوع المادة (بالريال لكل متر مربع)
  materials: {
    'vinyl-white': 0, // الأساسي
    'vinyl-transparent': 20,
    'paper-coated': -10,
    'reflective': 80,
    'chrome': 120,
    'holographic': 100,
  },

  // تكاليف إضافية ثابتة
  additionalCosts: {
    lamination: {
      perSqm: 25, // السلفان لكل متر مربع
    },
    embossing: {
      perSqm: 30, // البصمة لكل متر مربع
      colorCost: 10, // تكلفة إضافية للون البصمة
    },
    silkScreen: {
      perSqm: 40, // طباعة سلك سكرين لكل متر مربع
    },
    spotUV: {
      perSqm: 35, // سبوت UV لكل متر مربع
    },
  },

  // تكلفة التركيب
  assembly: {
    manual: 0, // يدوي
    automatic: 50, // آلي (تكلفة ثابتة)
  },

  // تكلفة حسب الشكل (نسبة مئوية إضافية)
  shapes: {
    circle: 1.1, // دائري - زيادة 10%
    square: 1.0, // مربع - لا زيادة
    rectangle: 1.0, // مستطيل - لا زيادة
    custom: 1.25, // شكل آخر - زيادة 25%
  },

  // تكلفة الحواف المستديرة للمربع
  roundedCorners: {
    cost: 15, // تكلفة ثابتة
  },

  // تكلفة إضافية لكل تصميم إضافي
  designCost: {
    perDesign: 20,
  },

  // نسبة الضريبة
  taxRate: 0.15, // 15%
};

// دالة حساب السعر الإجمالي
export function calculateTotalPrice(params: {
  length: number; // سم
  width: number; // سم
  quantity: number;
  shape: string;
  cornerType?: string;
  printType: string;
  designCount: number;
  material: string;
  hasLamination: boolean;
  hasEmbossing: boolean;
  embossingColor?: string;
  hasSilkScreen: boolean;
  hasSpotUV: boolean;
  assembly: string;
}) {
  const {
    length,
    width,
    quantity,
    shape,
    cornerType,
    printType,
    designCount,
    material,
    hasLamination,
    hasEmbossing,
    embossingColor,
    hasSilkScreen,
    hasSpotUV,
    assembly,
  } = params;

  // حساب المساحة
  const areaPerStickerCm2 = length * width;
  const areaPerStickerM2 = areaPerStickerCm2 / 10000; // تحويل من سم² إلى م²
  const totalAreaM2 = areaPerStickerM2 * quantity;

  // السعر الأساسي
  let pricePerSqm = PRICING_CONFIG.basePricePerSqm;

  // إضافة تكلفة نوع الطباعة
  pricePerSqm += PRICING_CONFIG.printTypes[printType as keyof typeof PRICING_CONFIG.printTypes] || 0;

  // إضافة تكلفة المادة
  pricePerSqm += PRICING_CONFIG.materials[material as keyof typeof PRICING_CONFIG.materials] || 0;

  // إضافة السلفان
  if (hasLamination) {
    pricePerSqm += PRICING_CONFIG.additionalCosts.lamination.perSqm;
  }

  // إضافة البصمة
  if (hasEmbossing) {
    pricePerSqm += PRICING_CONFIG.additionalCosts.embossing.perSqm;
    if (embossingColor) {
      pricePerSqm += PRICING_CONFIG.additionalCosts.embossing.colorCost;
    }
  }

  // إضافة سلك سكرين
  if (hasSilkScreen) {
    pricePerSqm += PRICING_CONFIG.additionalCosts.silkScreen.perSqm;
  }

  // إضافة سبوت UV
  if (hasSpotUV) {
    pricePerSqm += PRICING_CONFIG.additionalCosts.spotUV.perSqm;
  }

  // حساب السعر حسب المساحة
  let subtotal = totalAreaM2 * pricePerSqm;

  // تطبيق نسبة الشكل
  const shapeMultiplier = PRICING_CONFIG.shapes[shape as keyof typeof PRICING_CONFIG.shapes] || 1.0;
  subtotal *= shapeMultiplier;

  // إضافة تكلفة الحواف المستديرة
  if (shape === 'square' && cornerType === 'rounded') {
    subtotal += PRICING_CONFIG.roundedCorners.cost;
  }

  // إضافة تكلفة التصاميم الإضافية
  if (designCount > 1) {
    subtotal += (designCount - 1) * PRICING_CONFIG.designCost.perDesign;
  }

  // إضافة تكلفة التركيب
  if (assembly === 'automatic') {
    subtotal += PRICING_CONFIG.assembly.automatic;
  }

  // حساب الضريبة
  const tax = subtotal * PRICING_CONFIG.taxRate;
  const total = subtotal + tax;

  // حساب سعر الوحدة
  const unitPrice = quantity > 0 ? total / quantity : 0;

  return {
    totalAreaM2,
    subtotal,
    tax,
    total,
    unitPrice,
  };
}
