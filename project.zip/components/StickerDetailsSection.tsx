import { Sticker, Ruler, Layers, FileText, Sparkles, Droplet, Zap, Settings, RotateCw } from 'lucide-react';

interface StickerDetailsSectionProps {
  length: string;
  setLength: (value: string) => void;
  width: string;
  setWidth: (value: string) => void;
  quantity: string;
  setQuantity: (value: string) => void;
  shape: string;
  setShape: (value: string) => void;
  cornerType: string;
  setCornerType: (value: string) => void;
  printType: string;
  setPrintType: (value: string) => void;
  designCount: string;
  setDesignCount: (value: string) => void;
  material: string;
  setMaterial: (value: string) => void;
  hasLamination: boolean;
  setHasLamination: (value: boolean) => void;
  hasEmbossing: boolean;
  setHasEmbossing: (value: boolean) => void;
  embossingColor: string;
  setEmbossingColor: (value: string) => void;
  hasSilkScreen: boolean;
  setHasSilkScreen: (value: boolean) => void;
  hasSpotUV: boolean;
  setHasSpotUV: (value: boolean) => void;
  assembly: string;
  setAssembly: (value: string) => void;
  rollDirection: string;
  setRollDirection: (value: string) => void;
}

export function StickerDetailsSection(props: StickerDetailsSectionProps) {
  const {
    length, setLength,
    width, setWidth,
    quantity, setQuantity,
    shape, setShape,
    cornerType, setCornerType,
    printType, setPrintType,
    designCount, setDesignCount,
    material, setMaterial,
    hasLamination, setHasLamination,
    hasEmbossing, setHasEmbossing,
    embossingColor, setEmbossingColor,
    hasSilkScreen, setHasSilkScreen,
    hasSpotUV, setHasSpotUV,
    assembly, setAssembly,
    rollDirection, setRollDirection,
  } = props;

  return (
    <div className="bg-white rounded-2xl p-6 md:p-8 shadow-lg border border-gray-100">
      <div className="flex items-center gap-3 mb-8 pb-4 border-b-2 border-orange-100">
        <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-orange-700 rounded-xl flex items-center justify-center shadow-md">
          <Sticker className="w-6 h-6 text-white" />
        </div>
        <div>
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900">مواصفات الاستيكر</h2>
          <p className="text-sm text-gray-500 mt-0.5">حدد المقاسات والخيارات المطلوبة</p>
        </div>
      </div>

      <div className="space-y-8">
        {/* المقاس والكمية - في صف واحد للوضوح */}
        <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-6 border-2 border-blue-100">
          <h3 className="text-lg font-bold text-gray-900 mb-5 flex items-center gap-2">
            <Ruler className="w-5 h-5 text-blue-600" />
            المقاسات والكمية
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {/* الطول */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                الطول (سم) <span className="text-red-500">*</span>
              </label>
              <input
                type="number"
                placeholder="10"
                value={length}
                onChange={(e) => setLength(e.target.value)}
                className="w-full bg-white border-2 border-blue-200 rounded-xl px-4 py-3.5 text-gray-900 text-lg font-semibold placeholder-gray-400 focus:border-blue-500 focus:outline-none focus:ring-4 focus:ring-blue-100 transition-all"
              />
            </div>

            {/* العرض */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                العرض (سم) <span className="text-red-500">*</span>
              </label>
              <input
                type="number"
                placeholder="10"
                value={width}
                onChange={(e) => setWidth(e.target.value)}
                className="w-full bg-white border-2 border-blue-200 rounded-xl px-4 py-3.5 text-gray-900 text-lg font-semibold placeholder-gray-400 focus:border-blue-500 focus:outline-none focus:ring-4 focus:ring-blue-100 transition-all"
              />
            </div>

            {/* الكمية */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                الكمية <span className="text-red-500">*</span>
              </label>
              <input
                type="number"
                placeholder="100"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                className="w-full bg-white border-2 border-blue-200 rounded-xl px-4 py-3.5 text-gray-900 text-lg font-semibold placeholder-gray-400 focus:border-blue-500 focus:outline-none focus:ring-4 focus:ring-blue-100 transition-all"
              />
            </div>
          </div>
        </div>

        {/* الشكل */}
        <div>
          <label className="flex items-center gap-2 text-base font-bold text-gray-900 mb-4">
            <Sticker className="w-5 h-5 text-orange-600" />
            شكل الاستيكر
          </label>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { value: 'circle', label: 'دائري', icon: '⭕' },
              { value: 'square', label: 'مربع', icon: '⬜' },
              { value: 'rectangle', label: 'مستطيل', icon: '▭' },
              { value: 'custom', label: 'شكل آخر', icon: '✂️' },
            ].map((item) => (
              <button
                key={item.value}
                onClick={() => setShape(item.value)}
                className={`px-4 py-4 rounded-xl border-2 transition-all duration-200 ${
                  shape === item.value
                    ? 'bg-gradient-to-br from-orange-500 to-orange-600 text-white border-orange-600 shadow-lg scale-105'
                    : 'bg-white text-gray-700 border-gray-200 hover:border-orange-300 hover:shadow-md'
                }`}
              >
                <div className="text-2xl mb-1">{item.icon}</div>
                <div className="text-sm font-semibold">{item.label}</div>
              </button>
            ))}
          </div>
        </div>

        {/* نوع الحواف */}
        {shape === 'square' && (
          <div className="bg-orange-50 border-2 border-orange-200 rounded-xl p-5 animate-fadeIn">
            <label className="flex items-center gap-2 text-sm font-bold text-gray-900 mb-3">
              نوع الحواف للمربع
            </label>
            <div className="grid grid-cols-2 gap-3">
              {[
                { value: 'normal', label: 'حواف عادية' },
                { value: 'rounded', label: 'حواف مستديرة' },
              ].map((item) => (
                <button
                  key={item.value}
                  onClick={() => setCornerType(item.value)}
                  className={`px-4 py-3 rounded-xl border-2 transition-all ${
                    cornerType === item.value
                      ? 'bg-orange-500 text-white border-orange-600 shadow-md'
                      : 'bg-white text-gray-700 border-orange-200 hover:border-orange-400'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* نوع الطباعة */}
        <div>
          <label className="flex items-center gap-2 text-base font-bold text-gray-900 mb-4">
            <Droplet className="w-5 h-5 text-blue-600" />
            نوع الطباعة
          </label>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { value: 'cmyk-4', label: 'CMYK', subtitle: '4 ألوان' },
              { value: 'colors-5', label: '5 ألوان', subtitle: 'احترافي' },
              { value: 'colors-6', label: '6 ألوان', subtitle: 'متقدم' },
              { value: 'colors-7', label: '7 ألوان', subtitle: 'فائق' },
            ].map((item) => (
              <button
                key={item.value}
                onClick={() => setPrintType(item.value)}
                className={`px-4 py-4 rounded-xl border-2 transition-all ${
                  printType === item.value
                    ? 'bg-gradient-to-br from-blue-500 to-blue-700 text-white border-blue-700 shadow-lg'
                    : 'bg-white text-gray-700 border-gray-200 hover:border-blue-300 hover:shadow-md'
                }`}
              >
                <div className="font-bold text-base">{item.label}</div>
                <div className="text-xs mt-1 opacity-80">{item.subtitle}</div>
              </button>
            ))}
          </div>
        </div>

        {/* عدد التصاميم ونوع المادة */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* عدد التصاميم */}
          <div>
            <label className="flex items-center gap-2 text-base font-bold text-gray-900 mb-3">
              <FileText className="w-5 h-5 text-purple-600" />
              عدد التصاميم
            </label>
            <select
              value={designCount}
              onChange={(e) => setDesignCount(e.target.value)}
              className="w-full bg-white border-2 border-gray-200 rounded-xl px-4 py-3.5 text-gray-900 font-medium focus:border-blue-500 focus:outline-none focus:ring-4 focus:ring-blue-100 transition-all cursor-pointer"
            >
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((num) => (
                <option key={num} value={num}>
                  {num} {num === 1 ? 'تصميم' : 'تصاميم'}
                </option>
              ))}
            </select>
          </div>

          {/* نوع المادة */}
          <div>
            <label className="flex items-center gap-2 text-base font-bold text-gray-900 mb-3">
              <Layers className="w-5 h-5 text-green-600" />
              نوع المادة (الورق)
            </label>
            <select
              value={material}
              onChange={(e) => setMaterial(e.target.value)}
              className="w-full bg-white border-2 border-gray-200 rounded-xl px-4 py-3.5 text-gray-900 font-medium focus:border-blue-500 focus:outline-none focus:ring-4 focus:ring-blue-100 transition-all cursor-pointer"
            >
              <option value="vinyl-white">فينيل أبيض - قياسي</option>
              <option value="vinyl-transparent">فينيل شفاف - مميز</option>
              <option value="paper-coated">ورق مطلي - اقتصادي</option>
              <option value="reflective">عاكس للضوء - متميز</option>
              <option value="chrome">كروم - فاخر</option>
              <option value="holographic">هولوجرافيك - حصري</option>
            </select>
          </div>
        </div>

        {/* الخيارات الإضافية */}
        <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-6 border-2 border-purple-100">
          <h3 className="text-lg font-bold text-gray-900 mb-5 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-600" />
            الخيارات الإضافية والتشطيبات
          </h3>

          <div className="space-y-4">
            {/* السلفان */}
            <div className="flex items-center justify-between bg-white rounded-xl p-4 border-2 border-purple-100 hover:border-purple-300 transition-all">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Layers className="w-5 h-5 text-purple-600" />
                </div>
                <div>
                  <label className="text-gray-900 font-semibold cursor-pointer block">السلفان (Lamination)</label>
                  <p className="text-xs text-gray-500">حماية إضافية ولمعان</p>
                </div>
              </div>
              <button
                onClick={() => setHasLamination(!hasLamination)}
                className={`px-8 py-2.5 rounded-lg font-bold transition-all shadow-md ${
                  hasLamination
                    ? 'bg-gradient-to-r from-green-500 to-green-600 text-white'
                    : 'bg-gray-200 text-gray-600 hover:bg-gray-300'
                }`}
              >
                {hasLamination ? '✓ نعم' : 'لا'}
              </button>
            </div>

            {/* البصمة */}
            <div className="bg-white rounded-xl p-4 border-2 border-purple-100 hover:border-purple-300 transition-all">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
                    <Sparkles className="w-5 h-5 text-indigo-600" />
                  </div>
                  <div>
                    <label className="text-gray-900 font-semibold cursor-pointer block">البصمة (Embossing)</label>
                    <p className="text-xs text-gray-500">تأثير بارز ثلاثي الأبعاد</p>
                  </div>
                </div>
                <button
                  onClick={() => setHasEmbossing(!hasEmbossing)}
                  className={`px-8 py-2.5 rounded-lg font-bold transition-all shadow-md ${
                    hasEmbossing
                      ? 'bg-gradient-to-r from-green-500 to-green-600 text-white'
                      : 'bg-gray-200 text-gray-600 hover:bg-gray-300'
                  }`}
                >
                  {hasEmbossing ? '✓ نعم' : 'لا'}
                </button>
              </div>
              
              {hasEmbossing && (
                <div className="mt-4 pt-4 border-t-2 border-purple-100 animate-fadeIn">
                  <label className="block text-sm font-semibold text-gray-700 mb-2">لون البصمة</label>
                  <select
                    value={embossingColor}
                    onChange={(e) => setEmbossingColor(e.target.value)}
                    className="w-full bg-purple-50 border-2 border-purple-200 rounded-xl px-4 py-3 text-gray-900 font-medium focus:border-purple-500 focus:outline-none transition-all"
                  >
                    <option value="">بدون لون محدد</option>
                    <option value="gold">ذهبي ✨</option>
                    <option value="silver">فضي 🌟</option>
                    <option value="black">أسود ⚫</option>
                    <option value="white">أبيض ⚪</option>
                  </select>
                </div>
              )}
            </div>

            {/* سلك سكرين */}
            <div className="flex items-center justify-between bg-white rounded-xl p-4 border-2 border-purple-100 hover:border-purple-300 transition-all">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Droplet className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <label className="text-gray-900 font-semibold cursor-pointer block">طباعة سلك سكرين</label>
                  <p className="text-xs text-gray-500">طباعة احترافية للتفاصيل</p>
                </div>
              </div>
              <button
                onClick={() => setHasSilkScreen(!hasSilkScreen)}
                className={`px-8 py-2.5 rounded-lg font-bold transition-all shadow-md ${
                  hasSilkScreen
                    ? 'bg-gradient-to-r from-green-500 to-green-600 text-white'
                    : 'bg-gray-200 text-gray-600 hover:bg-gray-300'
                }`}
              >
                {hasSilkScreen ? '✓ نعم' : 'لا'}
              </button>
            </div>

            {/* سبوت UV */}
            <div className="flex items-center justify-between bg-white rounded-xl p-4 border-2 border-purple-100 hover:border-purple-300 transition-all">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
                  <Zap className="w-5 h-5 text-yellow-600" />
                </div>
                <div>
                  <label className="text-gray-900 font-semibold cursor-pointer block">سبوت UV</label>
                  <p className="text-xs text-gray-500">لمعان انتقائي فاخر</p>
                </div>
              </div>
              <button
                onClick={() => setHasSpotUV(!hasSpotUV)}
                className={`px-8 py-2.5 rounded-lg font-bold transition-all shadow-md ${
                  hasSpotUV
                    ? 'bg-gradient-to-r from-green-500 to-green-600 text-white'
                    : 'bg-gray-200 text-gray-600 hover:bg-gray-300'
                }`}
              >
                {hasSpotUV ? '✓ نعم' : 'لا'}
              </button>
            </div>
          </div>
        </div>

        {/* التركيب واتجاه الرول */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* التركيب */}
          <div>
            <label className="flex items-center gap-2 text-base font-bold text-gray-900 mb-3">
              <Settings className="w-5 h-5 text-teal-600" />
              نوع التركيب
            </label>
            <div className="grid grid-cols-2 gap-3">
              {[
                { value: 'manual', label: 'يدوي', icon: '✋' },
                { value: 'automatic', label: 'آلي', icon: '⚙️' },
              ].map((item) => (
                <button
                  key={item.value}
                  onClick={() => setAssembly(item.value)}
                  className={`px-4 py-4 rounded-xl border-2 transition-all ${
                    assembly === item.value
                      ? 'bg-gradient-to-br from-teal-500 to-teal-700 text-white border-teal-700 shadow-lg'
                      : 'bg-white text-gray-700 border-gray-200 hover:border-teal-300 hover:shadow-md'
                  }`}
                >
                  <div className="text-xl mb-1">{item.icon}</div>
                  <div className="text-sm font-semibold">{item.label}</div>
                </button>
              ))}
            </div>
          </div>

          {/* اتجاه الرول */}
          <div>
            <label className="flex items-center gap-2 text-base font-bold text-gray-900 mb-3">
              <RotateCw className="w-5 h-5 text-pink-600" />
              اتجاه الرول
            </label>
            <select
              value={rollDirection}
              onChange={(e) => setRollDirection(e.target.value)}
              className="w-full bg-white border-2 border-gray-200 rounded-xl px-4 py-3.5 text-gray-900 font-medium focus:border-blue-500 focus:outline-none focus:ring-4 focus:ring-blue-100 transition-all cursor-pointer"
            >
              <option value="horizontal">🔄 أفقي (Horizontal)</option>
              <option value="vertical">⬆️ عمودي (Vertical)</option>
              <option value="out-1">➡️ خارج 1 (Out 1)</option>
              <option value="out-3">⬅️ خارج 3 (Out 3)</option>
              <option value="out-8">⬇️ خارج 8 (Out 8)</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );
}
