import { Calculator } from 'lucide-react';

interface InputSectionProps {
  material: string;
  setMaterial: (value: string) => void;
  printType: string;
  setPrintType: (value: string) => void;
  width: string;
  setWidth: (value: string) => void;
  height: string;
  setHeight: (value: string) => void;
  quantity: string;
  setQuantity: (value: string) => void;
  lamination: string;
  setLamination: (value: string) => void;
  cutting: string;
  setCutting: (value: string) => void;
}

export function InputSection({
  material,
  setMaterial,
  printType,
  setPrintType,
  width,
  setWidth,
  height,
  setHeight,
  quantity,
  setQuantity,
  lamination,
  setLamination,
  cutting,
  setCutting,
}: InputSectionProps) {
  return (
    <div className="bg-[#1F1F1F] border border-[#333] rounded-lg p-8">
      <div className="flex items-center gap-3 mb-8">
        <Calculator className="w-6 h-6 text-[#CCFF00]" />
        <h2 className="text-2xl">Calculation Parameters</h2>
      </div>

      <div className="space-y-6">
        {/* Material Selection */}
        <div>
          <label className="block text-sm text-gray-400 mb-2">Material Type</label>
          <select
            value={material}
            onChange={(e) => setMaterial(e.target.value)}
            className="w-full bg-[#111111] border border-[#333] rounded-lg px-4 py-3 text-white focus:border-[#CCFF00] focus:outline-none transition-colors"
          >
            <option value="white-vinyl">White Vinyl</option>
            <option value="clear-vinyl">Clear Vinyl</option>
            <option value="coated-paper">Coated Paper</option>
            <option value="reflective">Reflective</option>
            <option value="gold-silver">Gold/Silver</option>
          </select>
        </div>

        {/* Print Type */}
        <div>
          <label className="block text-sm text-gray-400 mb-3">Print Type</label>
          <div className="grid grid-cols-3 gap-3">
            {['full-color', 'black-white', 'no-print'].map((type) => (
              <button
                key={type}
                onClick={() => setPrintType(type)}
                className={`px-4 py-3 rounded-lg border transition-all ${
                  printType === type
                    ? 'bg-[#CCFF00] text-black border-[#CCFF00]'
                    : 'bg-[#111111] text-white border-[#333] hover:border-[#555]'
                }`}
              >
                {type === 'full-color' ? 'Full Color' : type === 'black-white' ? 'Black & White' : 'No Print'}
              </button>
            ))}
          </div>
        </div>

        {/* Dimensions */}
        <div>
          <label className="block text-sm text-gray-400 mb-2">Dimensions (cm)</label>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <input
                type="number"
                placeholder="Width"
                value={width}
                onChange={(e) => setWidth(e.target.value)}
                className="w-full bg-[#111111] border border-[#333] rounded-lg px-4 py-3 text-white focus:border-[#CCFF00] focus:outline-none transition-colors"
              />
              <span className="text-xs text-gray-500 mt-1 block">Width</span>
            </div>
            <div>
              <input
                type="number"
                placeholder="Height"
                value={height}
                onChange={(e) => setHeight(e.target.value)}
                className="w-full bg-[#111111] border border-[#333] rounded-lg px-4 py-3 text-white focus:border-[#CCFF00] focus:outline-none transition-colors"
              />
              <span className="text-xs text-gray-500 mt-1 block">Height</span>
            </div>
          </div>
        </div>

        {/* Quantity */}
        <div>
          <label className="block text-sm text-gray-400 mb-2">Quantity</label>
          <input
            type="number"
            placeholder="Number of stickers"
            value={quantity}
            onChange={(e) => setQuantity(e.target.value)}
            className="w-full bg-[#111111] border border-[#333] rounded-lg px-4 py-3 text-white focus:border-[#CCFF00] focus:outline-none transition-colors"
          />
        </div>

        {/* Finishing Options */}
        <div className="pt-4 border-t border-[#333]">
          <h3 className="text-lg mb-4">Finishing Options</h3>
          
          {/* Lamination */}
          <div className="mb-6">
            <label className="block text-sm text-gray-400 mb-3">Lamination</label>
            <div className="grid grid-cols-3 gap-3">
              {['matte', 'gloss', 'none'].map((type) => (
                <button
                  key={type}
                  onClick={() => setLamination(type)}
                  className={`px-4 py-3 rounded-lg border transition-all ${
                    lamination === type
                      ? 'bg-[#CCFF00] text-black border-[#CCFF00]'
                      : 'bg-[#111111] text-white border-[#333] hover:border-[#555]'
                  }`}
                >
                  {type.charAt(0).toUpperCase() + type.slice(1)}
                </button>
              ))}
            </div>
          </div>

          {/* Cutting */}
          <div>
            <label className="block text-sm text-gray-400 mb-3">Cutting Type</label>
            <div className="grid grid-cols-2 gap-3">
              {['half-cut', 'die-cut'].map((type) => (
                <button
                  key={type}
                  onClick={() => setCutting(type)}
                  className={`px-4 py-3 rounded-lg border transition-all ${
                    cutting === type
                      ? 'bg-[#CCFF00] text-black border-[#CCFF00]'
                      : 'bg-[#111111] text-white border-[#333] hover:border-[#555]'
                  }`}
                >
                  {type === 'half-cut' ? 'Half Cut' : 'Die Cut'}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
