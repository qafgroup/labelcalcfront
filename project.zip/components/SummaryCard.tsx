import { DollarSign, Ruler, Package } from 'lucide-react';

interface SummaryCardProps {
  totalSquareMeters: number;
  unitCost: number;
  totalCost: number;
}

export function SummaryCard({ totalSquareMeters, unitCost, totalCost }: SummaryCardProps) {
  return (
    <div className="sticky top-8">
      <div className="bg-[#1F1F1F] border border-[#333] rounded-lg p-8">
        <h2 className="text-2xl mb-8">Cost Summary</h2>

        <div className="space-y-6 mb-8">
          {/* Total Square Meters */}
          <div className="bg-[#111111] border border-[#333] rounded-lg p-6">
            <div className="flex items-center gap-3 mb-2">
              <Ruler className="w-5 h-5 text-[#CCFF00]" />
              <span className="text-sm text-gray-400">Total Area</span>
            </div>
            <div className="text-4xl mt-2">
              {totalSquareMeters.toFixed(4)} <span className="text-xl text-gray-400">m²</span>
            </div>
          </div>

          {/* Unit Cost */}
          <div className="bg-[#111111] border border-[#333] rounded-lg p-6">
            <div className="flex items-center gap-3 mb-2">
              <Package className="w-5 h-5 text-[#CCFF00]" />
              <span className="text-sm text-gray-400">Unit Cost</span>
            </div>
            <div className="text-4xl mt-2">
              ${unitCost.toFixed(2)} <span className="text-xl text-gray-400">per sticker</span>
            </div>
          </div>

          {/* Total Cost */}
          <div className="bg-gradient-to-br from-[#1a1a1a] to-[#111111] border-2 border-[#CCFF00] rounded-lg p-6">
            <div className="flex items-center gap-3 mb-2">
              <DollarSign className="w-5 h-5 text-[#CCFF00]" />
              <span className="text-sm text-[#CCFF00]">Total Cost</span>
            </div>
            <div className="text-5xl mt-2 text-[#CCFF00]">
              ${totalCost.toFixed(2)}
            </div>
          </div>
        </div>

        <button className="w-full bg-[#CCFF00] text-black py-4 rounded-lg text-lg hover:bg-[#d4ff1a] transition-colors shadow-lg">
          Generate Quote
        </button>

        {/* Additional Info */}
        <div className="mt-6 pt-6 border-t border-[#333]">
          <div className="text-xs text-gray-500 space-y-2">
            <p>• Prices calculated in real-time</p>
            <p>• Bulk discounts may apply</p>
            <p>• VAT/Tax not included</p>
          </div>
        </div>
      </div>
    </div>
  );
}
