import { Heart, Code } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-white border-t-2 border-gray-200 mt-16 py-8">
      <div className="max-w-[1600px] mx-auto px-4 md:px-8">
        <div className="text-center">
          <div className="flex items-center justify-center gap-2 text-gray-600 mb-3">
            <Code className="w-4 h-4" />
            <span className="text-sm font-medium">نظام حساب تكلفة الاستيكرات</span>
          </div>
          <div className="flex items-center justify-center gap-2 text-gray-500 text-xs">
            <span>صُمم بكل</span>
            <Heart className="w-4 h-4 text-red-500 fill-red-500" />
            <span>لشركات الطباعة</span>
          </div>
          <p className="text-xs text-gray-400 mt-3">جميع الحسابات تتم محلياً في المتصفح - لا توجد خوادم خارجية</p>
        </div>
      </div>
    </footer>
  );
}
