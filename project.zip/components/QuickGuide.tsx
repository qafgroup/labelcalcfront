import { Info, ArrowLeft } from 'lucide-react';
import { useState } from 'react';

export function QuickGuide() {
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) return null;

  return (
    <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-2xl p-6 mb-8 shadow-xl border-2 border-blue-400 animate-fadeIn">
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-4 flex-1">
          <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center flex-shrink-0">
            <Info className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <h3 className="text-xl font-bold mb-3">مرحباً بك في نظام حساب تكلفة الاستيكرات!</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 border border-white/20">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-lg">1️⃣</span>
                  <span className="font-bold">أدخل بيانات العميل</span>
                </div>
                <p className="text-blue-100 text-xs">املأ معلومات العميل والمندوب</p>
              </div>
              
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 border border-white/20">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-lg">2️⃣</span>
                  <span className="font-bold">حدد المواصفات</span>
                </div>
                <p className="text-blue-100 text-xs">اختر المقاس والشكل والخيارات</p>
              </div>
              
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 border border-white/20">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-lg">3️⃣</span>
                  <span className="font-bold">شاهد السعر مباشرة</span>
                </div>
                <p className="text-blue-100 text-xs">التكلفة تُحسب تلقائياً فوراً</p>
              </div>
            </div>
          </div>
        </div>
        
        <button
          onClick={() => setIsVisible(false)}
          className="text-white/80 hover:text-white hover:bg-white/10 rounded-lg p-2 transition-all flex-shrink-0"
          aria-label="إخفاء الدليل"
        >
          <ArrowLeft className="w-5 h-5 rotate-180" />
        </button>
      </div>
    </div>
  );
}
