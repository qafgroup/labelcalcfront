import { User } from 'lucide-react';

export function Header() {
  return (
    <header className="border-b border-[#333] bg-[#1F1F1F] px-8 py-4">
      <div className="flex items-center justify-between max-w-[1600px] mx-auto">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-[#CCFF00] rounded"></div>
          <h1 className="text-xl tracking-wide">Label Express</h1>
        </div>
        <button className="p-2 hover:bg-[#2a2a2a] rounded-lg transition-colors">
          <User className="w-6 h-6 text-[#CCFF00]" />
        </button>
      </div>
    </header>
  );
}
