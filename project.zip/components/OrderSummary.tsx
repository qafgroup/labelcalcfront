import { Receipt, DollarSign, Percent, CheckCircle2, TrendingUp, Package } from 'lucide-react';

interface OrderSummaryProps {
  totalAreaM2: number;
  subtotal: number;
  tax: number;
  total: number;
  unitPrice: number;
  onSubmit: () => void;
}

export function OrderSummary({
  totalAreaM2,
  subtotal,
  tax,
  total,
  unitPrice,
  onSubmit,
}: OrderSummaryProps) {
  return (
    <div className="lg:sticky lg:top-24">
      <div className="bg-gradient-to-br from-white to-blue-50 rounded-2xl p-6 md:p-8 shadow-xl border-2 border-blue-100">
        <div className="flex items-center gap-3 mb-6 pb-4 border-b-2 border-blue-200">
          <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-700 rounded-xl flex items-center justify-center shadow-md">
            <Receipt className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900">ملخص التكلفة</h2>
            <p className="text-sm text-gray-500 mt-0.5">حساب فوري ودقيق</p>
          </div>
        </div>

        <div className="space-y-4 mb-6">
          {/* المساحة الإجمالية */}
          <div className="bg-white rounded-xl p-5 border-2 border-gray-100 shadow-sm hover:shadow-md transition-all">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-semibold text-gray-600 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-blue-500" />
                المساحة الإجمالية
              </span>
              <span className="text-xs font-bold text-gray-500 bg-gray-100 px-2 py-1 rounded">م²</span>
            </div>
            <div className="text-3xl font-bold text-blue-600">
              {totalAreaM2.toFixed(4)}
            </div>
          </div>

          {/* سعر الوحدة */}
          <div className="bg-white rounded-xl p-5 border-2 border-gray-100 shadow-sm hover:shadow-md transition-all">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-semibold text-gray-600 flex items-center gap-2">
                <Package className="w-4 h-4 text-purple-500" />
                سعر الوحدة
              </span>
              <span className="text-xs font-bold text-gray-500 bg-gray-100 px-2 py-1 rounded">ريال</span>
            </div>
            <div className="text-3xl font-bold text-purple-600">
              {unitPrice.toFixed(2)}
            </div>
          </div>

          {/* الإجمالي قبل الضريبة */}
          <div className="bg-white rounded-xl p-5 border-2 border-gray-100 shadow-sm hover:shadow-md transition-all">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-semibold text-gray-600 flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-orange-500" />
                قبل الضريبة
              </span>
            </div>
            <div className="text-3xl font-bold text-gray-700">
              {subtotal.toFixed(2)} <span className="text-lg text-gray-500">ريال</span>
            </div>
          </div>

          {/* الضريبة */}
          <div className="bg-gradient-to-r from-amber-50 to-orange-50 rounded-xl p-5 border-2 border-orange-200 shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-semibold text-orange-700 flex items-center gap-2">
                <Percent className="w-4 h-4 text-orange-600" />
                ضريبة القيمة المضافة (15%)
              </span>
            </div>
            <div className="text-3xl font-bold text-orange-600">
              {tax.toFixed(2)} <span className="text-lg text-orange-500">ريال</span>
            </div>
          </div>

          {/* الإجمالي النهائي */}
          <div className="bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl p-6 shadow-2xl border-2 border-green-400 transform hover:scale-105 transition-all">
            <div className="flex items-center justify-between mb-3">
              <span className="text-base font-bold text-white flex items-center gap-2">
                <CheckCircle2 className="w-6 h-6 text-white" />
                الإجمالي النهائي
              </span>
              <div className="bg-white/20 backdrop-blur-sm px-3 py-1 rounded-lg">
                <span className="text-xs font-bold text-white">شامل الضريبة</span>
              </div>
            </div>
            <div className="text-5xl font-black text-white drop-shadow-lg">
              {total.toFixed(2)}
            </div>
            <div className="text-sm text-green-100 mt-2 font-semibold">ريال سعودي</div>
          </div>
        </div>

        {/* زر إرسال العرض */}
        <button
          onClick={onSubmit}
          className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white py-5 rounded-xl text-lg font-bold transition-all shadow-xl hover:shadow-2xl flex items-center justify-center gap-3 transform hover:scale-105 active:scale-95"
        >
          <Receipt className="w-6 h-6" />
          <span>إرسال العرض للعميل</span>
        </button>

        {/* ملاحظات */}
        <div className="mt-6 pt-6 border-t-2 border-blue-100">
          <div className="bg-blue-50 rounded-xl p-4 border border-blue-200">
            <h4 className="text-sm font-bold text-blue-900 mb-3 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              ملاحظات مهمة
            </h4>
            <div className="text-xs text-blue-700 space-y-2">
              <p className="flex items-start gap-2">
                <span className="text-blue-500 mt-0.5">•</span>
                <span>الأسعار تُحدث تلقائياً مع كل تغيير</span>
              </p>
              <p className="flex items-start gap-2">
                <span className="text-blue-500 mt-0.5">•</span>
                <span>تطبق خصومات للكميات الكبيرة</span>
              </p>
              <p className="flex items-start gap-2">
                <span className="text-blue-500 mt-0.5">•</span>
                <span>جميع الأسعار شاملة الضريبة</span>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
