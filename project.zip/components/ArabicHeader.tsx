import { User, Package } from 'lucide-react';

export function ArabicHeader() {
  return (
    <header className="bg-white border-b-2 border-blue-100 px-4 md:px-8 py-5 sticky top-0 z-50 shadow-md">
      <div className="flex items-center justify-between max-w-[1600px] mx-auto">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-gradient-to-br from-blue-600 to-blue-800 rounded-xl flex items-center justify-center shadow-lg">
            <Package className="w-8 h-8 text-white" />
          </div>
          <div>
            <h1 className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-blue-700 to-blue-900 bg-clip-text text-transparent">
              طباعة الاستيكرات المتقدمة
            </h1>
            <p className="text-sm text-gray-500 font-medium mt-0.5">نظام إدارة الطلبات والتسعير</p>
          </div>
        </div>
        <button className="p-3 hover:bg-blue-50 rounded-xl transition-all duration-200 border border-gray-200">
          <User className="w-6 h-6 text-blue-700" />
        </button>
      </div>
    </header>
  );
}
