import { User, Calendar, Phone, UserCheck } from 'lucide-react';

interface CustomerInfoSectionProps {
  date: string;
  customerName: string;
  setCustomerName: (value: string) => void;
  customerNumber: string;
  setCustomerNumber: (value: string) => void;
  salesRep: string;
  setSalesRep: (value: string) => void;
  salesRepPhone: string;
  setSalesRepPhone: (value: string) => void;
}

export function CustomerInfoSection({
  date,
  customerName,
  setCustomerName,
  customerNumber,
  setCustomerNumber,
  salesRep,
  setSalesRep,
  salesRepPhone,
  setSalesRepPhone,
}: CustomerInfoSectionProps) {
  return (
    <div className="bg-white rounded-2xl p-6 md:p-8 shadow-lg border border-gray-100">
      <div className="flex items-center gap-3 mb-8 pb-4 border-b-2 border-blue-100">
        <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-700 rounded-xl flex items-center justify-center shadow-md">
          <User className="w-6 h-6 text-white" />
        </div>
        <div>
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900">بيانات العميل</h2>
          <p className="text-sm text-gray-500 mt-0.5">المعلومات الأساسية للطلب</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* التاريخ */}
        <div className="md:col-span-2">
          <label className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-3">
            <Calendar className="w-4 h-4 text-blue-600" />
            التاريخ
          </label>
          <div className="relative">
            <input
              type="text"
              value={date}
              readOnly
              className="w-full bg-blue-50 border-2 border-blue-100 rounded-xl px-4 py-3.5 text-gray-700 font-medium cursor-not-allowed"
            />
          </div>
        </div>

        {/* اسم العميل */}
        <div>
          <label className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-3">
            <User className="w-4 h-4 text-orange-600" />
            اسم العميل <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            value={customerName}
            onChange={(e) => setCustomerName(e.target.value)}
            placeholder="أدخل اسم العميل"
            className="w-full bg-white border-2 border-gray-200 rounded-xl px-4 py-3.5 text-gray-900 placeholder-gray-400 focus:border-blue-500 focus:outline-none focus:ring-4 focus:ring-blue-100 transition-all"
          />
        </div>

        {/* رقم العميل */}
        <div>
          <label className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-3">
            <Phone className="w-4 h-4 text-orange-600" />
            رقم العميل <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            value={customerNumber}
            onChange={(e) => setCustomerNumber(e.target.value)}
            placeholder="05xxxxxxxx"
            className="w-full bg-white border-2 border-gray-200 rounded-xl px-4 py-3.5 text-gray-900 placeholder-gray-400 focus:border-blue-500 focus:outline-none focus:ring-4 focus:ring-blue-100 transition-all"
          />
        </div>

        {/* المندوب */}
        <div>
          <label className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-3">
            <UserCheck className="w-4 h-4 text-orange-600" />
            اسم المندوب <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            value={salesRep}
            onChange={(e) => setSalesRep(e.target.value)}
            placeholder="اسم المندوب"
            className="w-full bg-white border-2 border-gray-200 rounded-xl px-4 py-3.5 text-gray-900 placeholder-gray-400 focus:border-blue-500 focus:outline-none focus:ring-4 focus:ring-blue-100 transition-all"
          />
        </div>

        {/* جوال المندوب */}
        <div>
          <label className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-3">
            <Phone className="w-4 h-4 text-orange-600" />
            جوال المندوب <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            value={salesRepPhone}
            onChange={(e) => setSalesRepPhone(e.target.value)}
            placeholder="05xxxxxxxx"
            className="w-full bg-white border-2 border-gray-200 rounded-xl px-4 py-3.5 text-gray-900 placeholder-gray-400 focus:border-blue-500 focus:outline-none focus:ring-4 focus:ring-blue-100 transition-all"
          />
        </div>
      </div>
    </div>
  );
}
