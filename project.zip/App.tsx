import { useState, useEffect } from 'react';
import { ArabicHeader } from './components/ArabicHeader';
import { QuickGuide } from './components/QuickGuide';
import { CustomerInfoSection } from './components/CustomerInfoSection';
import { StickerDetailsSection } from './components/StickerDetailsSection';
import { OrderSummary } from './components/OrderSummary';
import { CalculationIndicator } from './components/CalculationIndicator';
import { ScrollToTop } from './components/ScrollToTop';
import { Footer } from './components/Footer';
import { calculateTotalPrice } from './config/pricingConfig';

export default function App() {
  // بيانات العميل
  const [date, setDate] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [customerNumber, setCustomerNumber] = useState('');
  const [salesRep, setSalesRep] = useState('');
  const [salesRepPhone, setSalesRepPhone] = useState('');

  // بيانات الاستيكر
  const [length, setLength] = useState('10');
  const [width, setWidth] = useState('10');
  const [quantity, setQuantity] = useState('100');
  const [shape, setShape] = useState('rectangle');
  const [cornerType, setCornerType] = useState('normal');
  const [printType, setPrintType] = useState('cmyk-4');
  const [designCount, setDesignCount] = useState('1');
  const [material, setMaterial] = useState('vinyl-white');
  const [hasLamination, setHasLamination] = useState(false);
  const [hasEmbossing, setHasEmbossing] = useState(false);
  const [embossingColor, setEmbossingColor] = useState('');
  const [hasSilkScreen, setHasSilkScreen] = useState(false);
  const [hasSpotUV, setHasSpotUV] = useState(false);
  const [assembly, setAssembly] = useState('manual');
  const [rollDirection, setRollDirection] = useState('horizontal');

  // ملخص الطلب
  const [totalAreaM2, setTotalAreaM2] = useState(0);
  const [subtotal, setSubtotal] = useState(0);
  const [tax, setTax] = useState(0);
  const [total, setTotal] = useState(0);
  const [unitPrice, setUnitPrice] = useState(0);
  
  // حالة التحقق
  const [isFormValid, setIsFormValid] = useState(false);

  // تعيين التاريخ عند التحميل
  useEffect(() => {
    const today = new Date();
    const formattedDate = today.toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      weekday: 'long',
    });
    setDate(formattedDate);
  }, []);

  // حساب الأسعار تلقائياً عند تغيير أي حقل
  useEffect(() => {
    const result = calculateTotalPrice({
      length: parseFloat(length) || 0,
      width: parseFloat(width) || 0,
      quantity: parseInt(quantity) || 0,
      shape,
      cornerType,
      printType,
      designCount: parseInt(designCount) || 1,
      material,
      hasLamination,
      hasEmbossing,
      embossingColor,
      hasSilkScreen,
      hasSpotUV,
      assembly,
    });

    setTotalAreaM2(result.totalAreaM2);
    setSubtotal(result.subtotal);
    setTax(result.tax);
    setTotal(result.total);
    setUnitPrice(result.unitPrice);
    
    // التحقق من صحة النموذج
    const errors = validateForm();
    setIsFormValid(errors.length === 0 && result.total > 0);
  }, [
    length,
    width,
    quantity,
    shape,
    cornerType,
    printType,
    designCount,
    material,
    hasLamination,
    hasEmbossing,
    embossingColor,
    hasSilkScreen,
    hasSpotUV,
    assembly,
    customerName,
    customerNumber,
    salesRep,
    salesRepPhone,
  ]);

  // دالة التحقق من صحة البيانات
  const validateForm = () => {
    const errors: string[] = [];

    if (!customerName.trim()) errors.push('👤 اسم العميل مطلوب');
    if (!customerNumber.trim()) errors.push('📱 رقم العميل مطلوب');
    if (!salesRep.trim()) errors.push('👨‍💼 اسم المندوب مطلوب');
    if (!salesRepPhone.trim()) errors.push('☎️ جوال المندوب مطلوب');

    const lengthNum = parseFloat(length);
    const widthNum = parseFloat(width);
    const quantityNum = parseInt(quantity);

    if (!lengthNum || lengthNum <= 0) errors.push('📏 الطول يجب أن يكون أكبر من صفر');
    if (!widthNum || widthNum <= 0) errors.push('📐 العرض يجب أن يكون أكبر من صفر');
    if (!quantityNum || quantityNum <= 0) errors.push('🔢 الكمية يجب أن تكون أكبر من صفر');

    return errors;
  };

  // دالة إرسال العرض
  const handleSubmit = () => {
    const errors = validateForm();

    if (errors.length > 0) {
      // عرض الأخطاء بشكل أفضل
      const errorMessage = `⚠️ يرجى تصحيح الأخطاء التالية:\n\n${errors.map((err, i) => `${i + 1}. ${err}`).join('\n')}`;
      alert(errorMessage);
      return;
    }

    const orderData = {
      customerInfo: {
        date,
        customerName,
        customerNumber,
        salesRep,
        salesRepPhone,
      },
      stickerDetails: {
        dimensions: {
          length: parseFloat(length),
          width: parseFloat(width),
        },
        quantity: parseInt(quantity),
        shape,
        cornerType: shape === 'square' ? cornerType : null,
        printType,
        designCount: parseInt(designCount),
        material,
        options: {
          lamination: hasLamination,
          embossing: hasEmbossing ? { enabled: true, color: embossingColor } : { enabled: false },
          silkScreen: hasSilkScreen,
          spotUV: hasSpotUV,
        },
        assembly,
        rollDirection,
      },
      pricing: {
        totalAreaM2,
        subtotal,
        tax,
        total,
        unitPrice,
      },
    };

    console.log('=== بيانات الطلب ===');
    console.log(JSON.stringify(orderData, null, 2));
    
    alert(
      `✅ تم إنشاء العرض بنجاح!\n\n` +
      `📋 العميل: ${customerName}\n` +
      `📏 المساحة: ${totalAreaM2.toFixed(4)} م²\n` +
      `💰 الإجمالي: ${total.toFixed(2)} ريال\n` +
      `📦 الكمية: ${quantity} قطعة\n` +
      `💵 سعر الوحدة: ${unitPrice.toFixed(2)} ريال\n\n` +
      `📊 تفاصيل الطلب الكاملة في Console (F12)`
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      <ArabicHeader />

      <main className="max-w-[1600px] mx-auto px-4 md:px-8 py-8 md:py-12">
        {/* دليل سريع */}
        <QuickGuide />
        
        {/* بيانات العميل */}
        <div className="mb-8">
          <CustomerInfoSection
            date={date}
            customerName={customerName}
            setCustomerName={setCustomerName}
            customerNumber={customerNumber}
            setCustomerNumber={setCustomerNumber}
            salesRep={salesRep}
            setSalesRep={setSalesRep}
            salesRepPhone={salesRepPhone}
            setSalesRepPhone={setSalesRepPhone}
          />
        </div>

        {/* قسم التفاصيل والملخص */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* بيانات الاستيكر - يأخذ عمودين */}
          <div className="lg:col-span-2">
            <StickerDetailsSection
              length={length}
              setLength={setLength}
              width={width}
              setWidth={setWidth}
              quantity={quantity}
              setQuantity={setQuantity}
              shape={shape}
              setShape={setShape}
              cornerType={cornerType}
              setCornerType={setCornerType}
              printType={printType}
              setPrintType={setPrintType}
              designCount={designCount}
              setDesignCount={setDesignCount}
              material={material}
              setMaterial={setMaterial}
              hasLamination={hasLamination}
              setHasLamination={setHasLamination}
              hasEmbossing={hasEmbossing}
              setHasEmbossing={setHasEmbossing}
              embossingColor={embossingColor}
              setEmbossingColor={setEmbossingColor}
              hasSilkScreen={hasSilkScreen}
              setHasSilkScreen={setHasSilkScreen}
              hasSpotUV={hasSpotUV}
              setHasSpotUV={setHasSpotUV}
              assembly={assembly}
              setAssembly={setAssembly}
              rollDirection={rollDirection}
              setRollDirection={setRollDirection}
            />
          </div>

          {/* ملخص الطلب - يأخذ عمود واحد */}
          <div className="lg:col-span-1">
            <OrderSummary
              totalAreaM2={totalAreaM2}
              subtotal={subtotal}
              tax={tax}
              total={total}
              unitPrice={unitPrice}
              onSubmit={handleSubmit}
            />
          </div>
        </div>
      </main>
      
      {/* Footer */}
      <Footer />
      
      {/* مؤشر الجاهزية */}
      <CalculationIndicator isValid={isFormValid} />
      
      {/* زر العودة للأعلى */}
      <ScrollToTop />
    </div>
  );
}
